import sys, json, pickle, gzip, itertools, subprocess, math
sys.path.insert(0, '/home/claude/review/code')
from exact import facets, UA, hom, det, colsub, sgn
from sph import orient
B = '/home/claude/bundle/topdeg4/v10/'
Au = json.load(open('/home/claude/review/authorrun/spheres10.json')); Au = [sorted(tuple(f) for f in F) for F in Au]
M = pickle.load(open('/home/claude/review/out/listmap.pkl', 'rb')); a2l = M['a2l']; L = pickle.load(open('/home/claude/review/ext/lutz10.pkl', 'rb'))
S9 = sorted(tuple(f) for f in json.load(open(B + 'sphere_deg9.json'))['facets'])
print('regenerated author list: entry 101272 equals sphere_deg9.json facet for facet:', Au[101272] == S9, '-> Lutz', L[a2l[101272]][0], '|Aut| (canon.cpp) =', M['aut_lutz'][a2l[101272]])
res = {int(l.split()[0]): l.split()[1] for l in gzip.open(B + 'sweep_ge8_results.txt.gz', 'rt') if l.strip()}
sat = sorted(i for i, r in res.items() if r == 'SAT'); print('author results file: lines', len(res), 'indices 0..247881 all present:', set(res) == set(range(247882)), 'SAT', len(sat), 'equal to sat8_idx.json:', sat == json.load(open(B + 'sat8_idx.json')))
def canon(lists):
    inp = '\n'.join(str(len(F)) + ' ' + ' '.join(str(v) for f in F for v in f) for F in lists) + '\n'
    return [tuple(l.split()) for l in subprocess.run(['/home/claude/review/code/canon'], input=inp, capture_output=True, text=True).stdout.split('\n') if l]
R = {}
for f in ('real8_0.json', 'real8_1.json'): R.update(json.load(open(B + f)))
print('realizations supplied:', len(R))
ok = 0; info = {}
for key, A in sorted(R.items(), key=lambda kv: int(kv[0])):
    fac = facets(A); F = sorted(G for G, _ in fac)
    nv = len({v for G in F for v in G}); c = canon([F])[0]; ca = canon([Au[int(key)]])[0]
    good = UA(A) and nv == 10 and c == ca; ok += good
    # exact integer convex-hull check also: orientation from the hull equals a coherent orientation
    eps = orient(F); coh = len({eps[G] * e for G, e in fac}) == 1
    info[int(key)] = dict(lutz=L[a2l[int(key)]][0], facets=len(F), UA=UA(A), hull_is_type=c == ca, maxcoord=max(abs(x) for a in A for x in a), coherent=coh)
    print(key, info[int(key)])
print('realizations whose exact hull is a 10-vertex simplicial polytope of the stated combinatorial type:', ok, 'of', len(R))
print('SAT indices without a realization:', [i for i in sat if i not in info])
print('family type 82118: hull of A is type', canon([sorted(G for G, _ in facets(json.load(open(B + 'system_deg8_N10_small.json'))['A']))])[0] == canon([Au[82118]])[0], '-> Lutz', L[a2l[82118]][0])
pickle.dump({'sat_author': sat, 'real': sorted(info), 'a2l39': {i: a2l[i] for i in sat}}, open('/home/claude/review/out/item4d.pkl', 'wb'))
