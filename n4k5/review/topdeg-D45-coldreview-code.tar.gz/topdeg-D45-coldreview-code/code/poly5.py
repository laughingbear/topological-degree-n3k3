"""Reviewer's rank-5 test: uniform rank-5 chirotopes chi on the V vertices with chi(F,w) = eps_F for all facets F, w not in F,
satisfying the 3-term Grassmann-Pluecker relations (own encoder: enc.Base(V, 5))."""
import sys, itertools
sys.path.insert(0, '/home/claude/review/code')
from enc import Base
from sph import orient
from pysat.solvers import Solver
_b = {}
def base5(V):
    if V not in _b: _b[V] = Base(V, 5)
    return _b[V]
def units(V, F):
    b = base5(V); eps = orient(F); u = set()
    for G, e in eps.items():
        for w in range(V):
            if w not in G: u.add(e * b.lit(G + (w,)))
    return sorted(u, key=abs)
def enumerate_chi(V, F, solver='cd15', cap=100000):
    b = base5(V); u = units(V, F)
    if any(-l in u for l in u): return []
    models = []
    with Solver(name=solver, bootstrap_with=b.clauses + [[l] for l in u]) as s:
        while len(models) < cap and s.solve():
            m = s.get_model()[:b.nv]; models.append(m); s.add_clause([-l for l in m])
    return models
def polytopal_possible(V, F, solver='g4'):
    b = base5(V); u = units(V, F)
    if any(-l in set(u) for l in u): return False
    with Solver(name=solver, bootstrap_with=b.clauses + [[l] for l in u]) as s: return s.solve()
