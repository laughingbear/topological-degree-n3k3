// Reviewer's complete search for positive roots of F(x) = C x^A = 0, n = 4, in log coordinates y = log x.
// Branch and bound on a cube [-R,R]^4 with exclusion tests and a Krawczyk existence/uniqueness test.
// Exclusion tests (each is a proof, up to floating-point rounding, that a box has no root):
//  (gap)   at a root the largest monomial is at most 6*kappa times the 5th largest (kappa = max |C_T^{-1} C_j| entries)
//  (form)  some linear combination g = w C of the equations has sum g_i m_i of fixed sign on the box
//          (natural interval extension and mean-value form), w from: rows, all triples eliminated, J(y0)^{-1}
//  (kraw)  Krawczyk operator image disjoint from the box
// Certification: Krawczyk image inside the interior of the doubled box => exactly one root in the doubled box.
// input: N, A (N x 4 ints), C (4 x N ints), lambda = log(6 kappa), R, [part nparts]
#include <cstdio>
#include <cmath>
#include <vector>
#include <algorithm>
#include <cstdlib>
using namespace std;
typedef long double LD;
int N; double A[32][4], C[4][32]; double lam, R;
vector<vector<double>> forms;
struct Box { double c[4], r[4]; int depth; };
struct Root { LD y[4]; int sign; LD res; };
vector<Root> roots; long nbox = 0, nunres = 0, ncert = 0, kexc[5] = {0,0,0,0,0};
const double SLACK = 1e-9;
bool inv4(const double M[4][4], double Y[4][4]) {
  double a[4][8];
  for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) a[i][j] = j < 4 ? M[i][j] : (j - 4 == i);
  for (int c = 0; c < 4; c++) {
    int p = c; for (int i = c + 1; i < 4; i++) if (fabs(a[i][c]) > fabs(a[p][c])) p = i;
    if (fabs(a[p][c]) < 1e-300) return false;
    if (p != c) for (int j = 0; j < 8; j++) swap(a[p][j], a[c][j]);
    double d = a[c][c]; for (int j = 0; j < 8; j++) a[c][j] /= d;
    for (int i = 0; i < 4; i++) if (i != c) { double f = a[i][c]; if (f != 0) for (int j = 0; j < 8; j++) a[i][j] -= f * a[c][j]; }
  }
  for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) Y[i][j] = a[i][j + 4];
  return true;
}
// natural + mean value test for a form g on the box; elo/ehi/ec scaled monomial bounds
bool formtest(const double *g, const double *elo, const double *ehi, const double *ec, const double *r, bool mv) {
  double Plo = 0, Phi = 0, Nlo = 0, Nhi = 0;
  for (int i = 0; i < N; i++) { double gi = g[i]; if (gi > 0) { Plo += gi * elo[i]; Phi += gi * ehi[i]; } else if (gi < 0) { Nlo -= gi * elo[i]; Nhi -= gi * ehi[i]; } }
  if (Plo > Nhi * (1 + SLACK) || Nlo > Phi * (1 + SLACK)) return true;
  if (!mv) return false;
  double f0 = 0, rad = 0;
  for (int i = 0; i < N; i++) f0 += g[i] * ec[i];
  for (int k = 0; k < 4; k++) {
    double dlo = 0, dhi = 0;
    for (int i = 0; i < N; i++) { double t = g[i] * A[i][k]; if (t > 0) { dlo += t * elo[i]; dhi += t * ehi[i]; } else { dlo += t * ehi[i]; dhi += t * elo[i]; } }
    rad += r[k] * max(fabs(dlo), fabs(dhi));
  }
  return fabs(f0) > rad * (1 + SLACK) + 1e-13 * (Plo + Nlo + Phi + Nhi);
}
void FJ(const LD *y, LD *F, LD J[4][4]) {
  LD L[32], M = -1e300L;
  for (int i = 0; i < N; i++) { L[i] = 0; for (int k = 0; k < 4; k++) L[i] += A[i][k] * y[k]; M = max(M, L[i]); }
  for (int j = 0; j < 4; j++) { F[j] = 0; for (int k = 0; k < 4; k++) J[j][k] = 0; }
  for (int i = 0; i < N; i++) { LD e = expl(L[i] - M); for (int j = 0; j < 4; j++) { F[j] += C[j][i] * e; for (int k = 0; k < 4; k++) J[j][k] += C[j][i] * e * A[i][k]; } }
}
LD det4(LD M[4][4]) {
  LD a[4][4], d = 1; for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) a[i][j] = M[i][j];
  for (int c = 0; c < 4; c++) { int p = c; for (int i = c + 1; i < 4; i++) if (fabsl(a[i][c]) > fabsl(a[p][c])) p = i;
    if (a[p][c] == 0) return 0; if (p != c) { for (int j = 0; j < 4; j++) swap(a[p][j], a[c][j]); d = -d; }
    d *= a[c][c]; for (int i = c + 1; i < 4; i++) { LD f = a[i][c] / a[c][c]; for (int j = c; j < 4; j++) a[i][j] -= f * a[c][j]; } }
  return d;
}
bool solve4(LD J[4][4], const LD *F, LD *d) {
  LD a[4][5]; for (int i = 0; i < 4; i++) { for (int j = 0; j < 4; j++) a[i][j] = J[i][j]; a[i][4] = F[i]; }
  for (int c = 0; c < 4; c++) { int p = c; for (int i = c + 1; i < 4; i++) if (fabsl(a[i][c]) > fabsl(a[p][c])) p = i;
    if (a[p][c] == 0) return false; if (p != c) for (int j = 0; j < 5; j++) swap(a[p][j], a[c][j]);
    for (int i = 0; i < 4; i++) if (i != c) { LD f = a[i][c] / a[c][c]; for (int j = c; j < 5; j++) a[i][j] -= f * a[c][j]; } }
  for (int i = 0; i < 4; i++) d[i] = a[i][4] / a[i][i];
  return true;
}
void addroot(const double *c0) {
  LD y[4], F[4], J[4][4], d[4]; for (int k = 0; k < 4; k++) y[k] = c0[k];
  for (int it = 0; it < 60; it++) { FJ(y, F, J); if (!solve4(J, F, d)) break; LD s = 0; for (int k = 0; k < 4; k++) { y[k] -= d[k]; s = max(s, fabsl(d[k])); } if (s < 1e-17L) break; }
  for (auto &q : roots) { LD s = 0; for (int k = 0; k < 4; k++) s = max(s, fabsl(q.y[k] - y[k])); if (s < 1e-9L) return; }
  FJ(y, F, J); Root q; for (int k = 0; k < 4; k++) q.y[k] = y[k]; LD dd = det4(J); q.sign = dd > 0 ? 1 : -1; q.res = 0; for (int k = 0; k < 4; k++) q.res = max(q.res, fabsl(F[k])); roots.push_back(q);
}
// returns 0 excluded, 1 certified (root recorded), 2 undecided
int test(const Box &b) {
  double L[32], rho[32], lo[32], hi[32], elo[32], ehi[32], ec[32], M = -1e300, rhomax = 0;
  for (int i = 0; i < N; i++) { L[i] = 0; rho[i] = 0; for (int k = 0; k < 4; k++) { L[i] += A[i][k] * b.c[k]; rho[i] += A[i][k] * b.r[k]; }
    rho[i] *= (1 + 1e-12); rho[i] += 1e-12 * fabs(L[i]) + 1e-300; lo[i] = L[i] - rho[i]; hi[i] = L[i] + rho[i]; M = max(M, hi[i]); rhomax = max(rhomax, rho[i]); }
  // gap test
  { double mlo = -1e300; for (int i = 0; i < N; i++) mlo = max(mlo, lo[i]); double h[32]; for (int i = 0; i < N; i++) h[i] = hi[i];
    nth_element(h, h + 4, h + N, greater<double>()); if (mlo - h[4] > lam + 1e-9) { kexc[0]++; return 0; } }
  for (int i = 0; i < N; i++) { elo[i] = exp(lo[i] - M) * (1 - 1e-13); ehi[i] = exp(hi[i] - M) * (1 + 1e-13); ec[i] = exp(L[i] - M); }
  bool mv = rhomax < 4;
  for (auto &g : forms) if (formtest(g.data(), elo, ehi, ec, b.r, mv)) { kexc[1]++; return 0; }
  if (rhomax > 6) return 2;
  // Jacobian at centre (w.r.t. y), preconditioner
  double F0[4], Jc[4][4], Y[4][4];
  for (int j = 0; j < 4; j++) { F0[j] = 0; for (int k = 0; k < 4; k++) Jc[j][k] = 0; for (int i = 0; i < N; i++) { F0[j] += C[j][i] * ec[i]; for (int k = 0; k < 4; k++) Jc[j][k] += C[j][i] * A[i][k] * ec[i]; } }
  if (!inv4(Jc, Y)) return 2;
  double W[4][32];
  for (int j = 0; j < 4; j++) { for (int i = 0; i < N; i++) { W[j][i] = 0; for (int l = 0; l < 4; l++) W[j][i] += Y[j][l] * C[l][i]; }
    if (formtest(W[j], elo, ehi, ec, b.r, true)) { kexc[2]++; return 0; } }
  if (rhomax > 1.5) return 2;
  // Krawczyk on the doubled box B' = c +- 2r
  double r2[4], elo2[32], ehi2[32];
  for (int k = 0; k < 4; k++) r2[k] = 2 * b.r[k];
  for (int i = 0; i < N; i++) { double rr = 2 * rho[i]; elo2[i] = exp(L[i] - rr - M) * (1 - 1e-13); ehi2[i] = exp(L[i] + rr - M) * (1 + 1e-13); }
  double Jm[4][4], Jr[4][4];
  for (int j = 0; j < 4; j++) for (int k = 0; k < 4; k++) { double m = 0, rad = 0; for (int i = 0; i < N; i++) { double t = C[j][i] * A[i][k]; m += t * 0.5 * (ehi2[i] + elo2[i]); rad += fabs(t) * 0.5 * (ehi2[i] - elo2[i]); } Jm[j][k] = m; Jr[j][k] = rad; }
  double yf[4], E[4][4]; bool inside = true, disjoint = false;
  for (int k = 0; k < 4; k++) { yf[k] = 0; for (int l = 0; l < 4; l++) yf[k] += Y[k][l] * F0[l]; }
  for (int k = 0; k < 4; k++) for (int j = 0; j < 4; j++) { double m = (k == j), rad = 0; for (int l = 0; l < 4; l++) { m -= Y[k][l] * Jm[l][j]; rad += fabs(Y[k][l]) * Jr[l][j]; } E[k][j] = fabs(m) + rad; }
  for (int k = 0; k < 4; k++) { double rad = 0; for (int j = 0; j < 4; j++) rad += E[k][j] * r2[j]; rad = rad * (1 + 1e-9) + 1e-12 * fabs(yf[k]);
    if (fabs(yf[k]) + rad >= r2[k] * (1 - 1e-9)) inside = false;
    if (fabs(yf[k]) - rad > r2[k] * (1 + 1e-9)) disjoint = true; }
  if (disjoint) { kexc[3]++; return 0; }
  if (inside) { ncert++; addroot(b.c); return 1; }
  return 2;
}
int main(int argc, char **argv) {
  FILE *f = fopen(argv[1], "r"); if (fscanf(f, "%d", &N) != 1) return 1;
  for (int i = 0; i < N; i++) for (int k = 0; k < 4; k++) if (fscanf(f, "%lf", &A[i][k]) != 1) return 1;
  for (int j = 0; j < 4; j++) for (int i = 0; i < N; i++) if (fscanf(f, "%lf", &C[j][i]) != 1) return 1;
  if (fscanf(f, "%lf %lf", &lam, &R) != 2) return 1;
  int nf; if (fscanf(f, "%d", &nf) != 1) return 1;
  for (int q = 0; q < nf; q++) { vector<double> g(N); for (int i = 0; i < N; i++) if (fscanf(f, "%lf", &g[i]) != 1) return 1; forms.push_back(g); }
  int part = argc > 2 ? atoi(argv[2]) : 0, nparts = argc > 3 ? atoi(argv[3]) : 1;   // split along y0 into nparts slabs
  double minr = argc > 4 ? atof(argv[4]) : 1e-10;
  vector<Box> st; Box b0; for (int k = 0; k < 4; k++) { b0.c[k] = 0; b0.r[k] = R; } b0.depth = 0;
  b0.r[0] = R / nparts; b0.c[0] = -R + (2 * part + 1) * R / nparts; st.push_back(b0);
  while (!st.empty()) {
    Box b = st.back(); st.pop_back(); nbox++;
    int t = test(b); if (t != 2) continue;
    int k = 0; for (int j = 1; j < 4; j++) if (b.r[j] > b.r[k] * 1.0000001) k = j;
    if (b.r[k] < minr) { nunres++; printf("UNRESOLVED %.12g %.12g %.12g %.12g r=%g\n", b.c[0], b.c[1], b.c[2], b.c[3], b.r[k]); continue; }
    Box b1 = b, b2 = b; b1.r[k] = b2.r[k] = b.r[k] / 2; b1.c[k] = b.c[k] - b.r[k] / 2; b2.c[k] = b.c[k] + b.r[k] / 2; b1.depth = b2.depth = b.depth + 1;
    st.push_back(b1); st.push_back(b2);
    if (nbox % 20000000 == 0) { fprintf(stderr, "boxes %ld stack %zu roots %zu depth %d\n", nbox, st.size(), roots.size(), b.depth); }
  }
  for (auto &q : roots) printf("ROOT %.18Lg %.18Lg %.18Lg %.18Lg sign %d res %.3Lg\n", q.y[0], q.y[1], q.y[2], q.y[3], q.sign, q.res);
  printf("SUMMARY boxes %ld certified_boxes %ld roots %zu unresolved %ld excl gap %ld form %ld precond %ld kraw %ld\n", nbox, ncert, roots.size(), nunres, kexc[0], kexc[1], kexc[2], kexc[3]);
}
