// Reviewer's nauty-free canonical form of a simplicial 3-pseudomanifold with <= 16 vertices and <= 64 facets.
// Seeds: (facet f, ordering of its vertices) where f has the lexicographically smallest sorted vertex-degree tuple and the
// ordering has non-decreasing degrees (an isomorphism-invariant set of seeds).  For each seed, relabel by a deterministic
// breadth-first traversal over facets; the canonical form is the smallest sorted relabelled facet list.
// The number of seeds attaining the minimum equals the order of the automorphism group.
// input lines: nf v1 v2 v3 v4 ...   output lines: |Aut| facets
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int F[64][4], nb[64][4], nf, V, deg[16];
int main() {
  while (scanf("%d", &nf) == 1) {
    V = 0; memset(deg, 0, sizeof deg);
    for (int i = 0; i < nf; i++) { for (int k = 0; k < 4; k++) { if (scanf("%d", &F[i][k]) != 1) return 1; V = max(V, F[i][k] + 1); deg[F[i][k]]++; } sort(F[i], F[i] + 4); }
    static int tri[4096][2], tc[4096]; memset(tc, 0, sizeof tc); bool ok = true;
    auto key = [&](int i, int k) { int t = 0; for (int j = 0; j < 4; j++) if (j != k) t = t * 16 + F[i][j]; return t; };
    for (int i = 0; i < nf; i++) for (int k = 0; k < 4; k++) { int t = key(i, k); if (tc[t] < 2) tri[t][tc[t]] = i; tc[t]++; }
    for (int i = 0; i < nf && ok; i++) for (int k = 0; k < 4; k++) { int t = key(i, k); if (tc[t] != 2) { ok = false; break; } nb[i][k] = tri[t][0] == i ? tri[t][1] : tri[t][0]; }
    if (!ok) { printf("0 BAD\n"); continue; }
    int sig[64][4], bestsig[4] = {1 << 30, 0, 0, 0};
    for (int i = 0; i < nf; i++) { for (int k = 0; k < 4; k++) sig[i][k] = deg[F[i][k]]; sort(sig[i], sig[i] + 4); if (lexicographical_compare(sig[i], sig[i] + 4, bestsig, bestsig + 4)) memcpy(bestsig, sig[i], sizeof bestsig); }
    unsigned best[64], cur[64]; bool have = false; long cnt = 0;
    for (int f0 = 0; f0 < nf; f0++) {
      if (memcmp(sig[f0], bestsig, sizeof bestsig)) continue;
      int perm[4] = {0, 1, 2, 3};
      do {
        if (deg[F[f0][perm[0]]] > deg[F[f0][perm[1]]] || deg[F[f0][perm[1]]] > deg[F[f0][perm[2]]] || deg[F[f0][perm[2]]] > deg[F[f0][perm[3]]]) continue;
        int lab[16], q[64], qn = 0, nl = 0; bool seen[64]; memset(lab, -1, sizeof lab); memset(seen, 0, sizeof seen);
        for (int k = 0; k < 4; k++) lab[F[f0][perm[k]]] = nl++;
        q[qn++] = f0; seen[f0] = true;
        for (int h = 0; h < qn; h++) {
          int f = q[h], ord[4] = {0, 1, 2, 3};
          sort(ord, ord + 4, [&](int a, int b) { return lab[F[f][a]] < lab[F[f][b]]; });
          for (int a = 0; a < 4; a++) { int g = nb[f][ord[a]]; if (seen[g]) continue; seen[g] = true;
            for (int j = 0; j < 4; j++) if (lab[F[g][j]] < 0) lab[F[g][j]] = nl++;
            q[qn++] = g; }
        }
        for (int i = 0; i < nf; i++) { int r[4]; for (int k = 0; k < 4; k++) r[k] = lab[F[i][k]]; sort(r, r + 4); cur[i] = (r[0] << 12) | (r[1] << 8) | (r[2] << 4) | r[3]; }
        sort(cur, cur + nf);
        int c = have ? memcmp(cur, best, nf * sizeof(unsigned)) : -1;
        if (!have || lexicographical_compare(cur, cur + nf, best, best + nf)) { memcpy(best, cur, nf * sizeof(unsigned)); have = true; cnt = 1; }
        else if (c == 0) cnt++;
      } while (next_permutation(perm, perm + 4));
    }
    printf("%ld ", cnt); for (int i = 0; i < nf; i++) printf("%04x", best[i]); printf("\n");
  }
}
