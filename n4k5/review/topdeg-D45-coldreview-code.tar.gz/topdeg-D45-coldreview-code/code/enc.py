"""Reviewer's SAT encoder for "some uniform rank-4 chirotope on V points gives the oriented simplicial 3-sphere K a
vertex-map degree >= d, evaluated at u = -C_v for every vertex v".  Written from the definitions; differs from the
author's omsat.py: Grassmann-Pluecker clauses from a truth table of the polynomial identity; cone test in circuit form with
one shared pair of variables per 5-subset; hand-written sequential counter (no pysat.card)."""
import itertools
def perm_sign(t):
    s = 1
    for i in range(len(t)):
        for j in range(i + 1, len(t)):
            if t[i] > t[j]: s = -s
    return s
class Base:
    def __init__(self, V, r=4):
        self.V = V; self.r = r
        self.x = {S: i + 1 for i, S in enumerate(itertools.combinations(range(V), r))}
        self.nv = len(self.x); self.clauses = []
        self.gp()
        if r == 4: self.circuits()
    def new(self): self.nv += 1; return self.nv
    def lit(self, t):
        """literal true iff det of the columns in the order t is positive"""
        return self.x[tuple(sorted(t))] * perm_sign(t)
    def gp(self):
        r = self.r
        for sig in itertools.combinations(range(self.V), r - 2):
            rest = [z for z in range(self.V) if z not in sig]
            for a, b, c, d in itertools.combinations(rest, 4):
                six = [self.lit(sig + (a, b)), self.lit(sig + (c, d)), self.lit(sig + (a, c)), self.lit(sig + (b, d)), self.lit(sig + (a, d)), self.lit(sig + (b, c))]
                for bits in itertools.product((1, -1), repeat=6):
                    t1 = bits[0] * bits[1]; t2 = -bits[2] * bits[3]; t3 = bits[4] * bits[5]     # [ab][cd] - [ac][bd] + [ad][bc] = 0
                    if t1 == t2 == t3:                    # three nonzero numbers of one sign cannot sum to 0: forbid
                        self.clauses.append([-l if b == 1 else l for l, b in zip(six, bits)])
    def circuits(self):
        """zp[T] <-> all (-1)^j det(C_{T - t_j}) > 0 ; zn[T] <-> all < 0   (the 5 columns T positively dependent)"""
        self.zp = {}; self.zn = {}
        for T in itertools.combinations(range(self.V), 5):
            s = [self.x[T[:j] + T[j+1:]] * (-1) ** j for j in range(5)]
            p = self.new(); n = self.new(); self.zp[T] = p; self.zn[T] = n
            self.clauses += [[-p, l] for l in s] + [[p] + [-l for l in s]]
            self.clauses += [[-n, -l] for l in s] + [[n] + list(s)]
def at_most(lits, r, new):
    """Sinz sequential counter: at most r of lits true. returns clauses (None if r < 0)"""
    n = len(lits)
    if r < 0: return None
    if r >= n: return []
    if r == 0: return [[-l] for l in lits]
    cl = []; prev = None
    for i, y in enumerate(lits):
        cur = [new() for _ in range(r)]
        cl.append([-y, cur[0]])
        if prev is not None:
            for j in range(r): cl.append([-prev[j], cur[j]])
            for j in range(1, r): cl.append([-y, -prev[j-1], cur[j]])
            cl.append([-y, -prev[r-1]])
        prev = cur
    return cl
def sphere_clauses(base, eps, d, new):
    """eps: dict sorted facet -> +-1.  returns clause list, or None if trivially unsatisfiable.
    For vertex v and facet G not containing v, T = G+v sorted, v at position j: the contribution of G at u = -C_v is
    eps_G*sign det C_G if the five columns are positively dependent, i.e. eps_G*(-1)^j under zp[T], -eps_G*(-1)^j under zn[T]."""
    out = []
    for v in range(base.V):
        P = []; Ng = []
        for G, e in eps.items():
            if v in G: continue
            T = tuple(sorted(G + (v,))); j = T.index(v); s = e * (-1) ** j
            P.append(base.zp[T] if s > 0 else base.zn[T]); Ng.append(base.zn[T] if s > 0 else base.zp[T])
        m = len(P)                           # need #P - #Ng >= d  <=>  at most m-d of the literals (not P), (Ng) true
        cl = at_most([-p for p in P] + Ng, m - d, new)
        if cl is None: return None
        out += cl
    return out
def fix_chirotope(base, C):
    """unit clauses fixing x to the signs of the 4x4 minors of the integer matrix C (4 x V)"""
    from exact import det, colsub
    units = []
    for S, var in base.x.items():
        dd = det(colsub(C, S)); assert dd != 0
        units.append([var if dd > 0 else -var])
    return units
