"""V = 9: identify Firsching's 1142 polytopal spheres in Lutz's list (hull + canonical form); compare with the rank-5 test.
V = 10: the rank-5 test must be SAT on polytopal spheres: random sample of Firsching's list."""
import sys, re, pickle, subprocess, random
sys.path.insert(0, '/home/claude/review/code')
import numpy as np
from scipy.spatial import ConvexHull
from sph import lutz
from poly5 import polytopal_possible
E = '/home/claude/review/ext/'
def canon(lists):
    inp = '\n'.join(str(len(F)) + ' ' + ' '.join(str(v) for f in F for v in f) for F in lists) + '\n'
    return [tuple(l.split())[1:] for l in subprocess.run(['/home/claude/review/code/canon'], input=inp, capture_output=True, text=True).stdout.split('\n') if l]
num = re.compile(r'(-?\d+)(?:/(\d+))?')
L9 = [(n, F) for n, F in lutz(E + '3_manifolds_all.txt', E + '3_manifolds_all_type.txt') if 1 + max(max(f) for f in F) == 9]
c9 = canon([F for _, F in L9]); hulls = []
for l in open(E + 'poly9.txt'):
    if ':' not in l: continue
    v = [int(a) / int(b) if b else float(a) for a, b in num.findall(l.split(':', 1)[1])]
    h = ConvexHull(np.array(v).reshape(9, 4)); hulls.append(sorted(tuple(sorted(int(x) for x in s)) for s in h.simplices))
pol = set(canon(hulls)); print('V=9: Firsching realizations', len(hulls), 'distinct classes', len(pol), 'all among Lutz S^3:', pol <= set(c9))
uns = [n for (n, F), c in zip(L9, c9) if not polytopal_possible(9, F)]
nonpol = [n for (n, F), c in zip(L9, c9) if c not in pol]
print('V=9: non-polytopal (complement of Firsching)', len(nonpol), '| rank-5 UNSAT', len(uns), '| UNSAT subset of non-polytopal:', set(uns) <= set(nonpol), '| non-polytopal passing the rank-5 test:', sorted(set(nonpol) - set(uns)))
L = pickle.load(open(E + 'lutz10.pkl', 'rb')); P = pickle.load(open('/home/claude/review/out/firsching_map.pkl', 'rb'))['polytopal_lutz_idx']
random.seed(4); s = random.sample(P, 1500); bad = [L[i][0] for i in s if not polytopal_possible(10, L[i][1])]
print('V=10: rank-5 test on', len(s), 'random polytopal spheres (Firsching): UNSAT', len(bad))
pset = set(P); random.seed(5); npl = random.sample([i for i in range(len(L)) if i not in pset], 1500); u = sum(1 for i in npl if not polytopal_possible(10, L[i][1]))
print('V=10: rank-5 test on', len(npl), 'random non-polytopal spheres: UNSAT', u)
