"""write bnb input: system json (A,C) -> text with lambda (exact kappa) and the forms (rows + all eliminated triples)"""
import sys, json, itertools, math
sys.path.insert(0, '/home/claude/review/code')
from fractions import Fraction as Fr
from exact import det, colsub
def kappa(C):
    N = len(C[0]); kap = Fr(0)
    for T in itertools.combinations(range(N), 4):
        d = det(colsub(C, T))
        for j in range(N):
            if j in T: continue
            for c in range(4):
                cols = list(T); cols[c] = j; kap = max(kap, Fr(abs(det(colsub(C, cols))), abs(d)))
    return kap
def forms(C):
    N = len(C[0]); out = [list(r) for r in C]
    for T in itertools.combinations(range(N), 3):
        # w orthogonal to the three columns: generalized cross product; g_i = det[C_T, C_i]
        out.append([det([[C[r][t] for t in T] + [C[r][i]] for r in range(4)]) for i in range(N)])
    return out
def radius(A, lam):
    """every positive root has |log x_k| <= radius: at a root some 5 monomials S, with a largest one 'top', satisfy
    <a_i - a_top, y> in [-lam, 0] for i in S, so y = D^{-1} t with t in [-lam,0]^4 (D invertible by (U_A))."""
    import numpy as np
    N = len(A); R = 0.0
    for S in itertools.combinations(range(N), 5):
        for top in S:
            D = np.array([[A[i][k] - A[top][k] for k in range(4)] for i in S if i != top], float)
            R = max(R, lam * np.abs(np.linalg.inv(D)).sum(axis=1).max())
    return R
def write(A, C, R, path):
    lam = math.log(6 * float(kappa(C))) * (1 + 1e-12)
    if R is None: R = radius(A, lam) * 1.01
    print('lambda', round(lam, 4), 'R', round(R, 3), file=sys.stderr)
    with open(path, 'w') as f:
        f.write(f'{len(A)}\n' + '\n'.join(' '.join(map(str, a)) for a in A) + '\n' + '\n'.join(' '.join(map(str, r)) for r in C) + f'\n{lam!r} {R}\n')
        F = forms(C); f.write(f'{len(F)}\n' + '\n'.join(' '.join(map(str, g)) for g in F) + '\n')
if __name__ == '__main__':
    S = json.load(open(sys.argv[1])); C = S['C'] if 'C' in S else S['C_by_degree'][sys.argv[4]]
    write(S['A'], C, None if sys.argv[2] == 'auto' else float(sys.argv[2]), sys.argv[3])
