"""Reviewer's own degree-8 systems on the 22 polytopal types: A = the author's integer realization (checked exactly, shifted
to nonnegative exponents), C from the reviewer's hill-climber, degree by the reviewer's exact code.
stage 'climb': write one system file per type.  stage 'roots': complete root search (bnb) with a time limit per system."""
import sys, json, subprocess, os
sys.path.insert(0, '/home/claude/review/code')
from exact import facets, report, UC
import mkinput
B = '/home/claude/bundle/topdeg4/v10/'; O = '/home/claude/review/out/own8/'
R = {}
for f in ('real8_0.json', 'real8_1.json'): R.update(json.load(open(B + f)))
keys = sorted(R, key=int); stage = sys.argv[1]; part = int(sys.argv[2]); nparts = int(sys.argv[3])
for key in keys[part::nparts]:
    sysf = O + f'system_{key}.json'
    if stage == 'climb':
        if os.path.exists(sysf): continue
        A0 = R[key]; mn = [min(a[k] for a in A0) for k in range(4)]; A = [[a[k] - mn[k] for k in range(4)] for a in A0]
        fac = facets(A); F = [G for G, _ in fac]
        inp = f'10 {len(F)}\n' + '\n'.join(' '.join(map(str, G)) + f' {e}' for G, e in fac) + '\n'
        found = None; best = 0
        for seed in range(1, 16):
            o = subprocess.run(['/home/claude/review/code/climb', str(1000 * int(key) % 99991 + seed), '3000000', '3000', '8'], input=inp, capture_output=True, text=True).stdout.split('\n')
            b = int(o[0]); best = max(best, b)
            if b < 8: continue
            Cf = [list(map(float, l.split())) for l in o[1:11]]; mx = max(abs(x) for r in Cf for x in r)
            for scale in (8, 12, 20, 30, 50, 100, 300, 1000, 10000):
                Ci = [[round(Cf[v][r] / mx * scale) for v in range(10)] for r in range(4)]
                if not UC(Ci): continue
                rep = report(A, Ci)
                if rep['UA'] and rep['nvert'] == 10 and len(rep['degs']) == 1 and abs(rep['degs'][0]) == 8: found = (Ci, rep); break
            if found: break
        if not found: print(key, 'no degree-8 map found by the climber, best', best, flush=True); json.dump({'key': key, 'A': A, 'C': None, 'best': best}, open(sysf, 'w')); continue
        Ci, rep = found
        print(key, 'facets', rep['nfac'], 'max exponent', max(max(a) for a in A), 'max |C|', max(abs(x) for r_ in Ci for x in r_), 'exact degree', rep['degs'][0], 'over', rep['nu'], 'generic u', flush=True)
        json.dump({'key': key, 'A': A, 'C': Ci, 'degree': rep['degs'][0], 'facets': rep['nfac']}, open(sysf, 'w'))
    else:
        S = json.load(open(sysf)); rf = O + f'roots_{key}.txt'
        if S['C'] is None or os.path.exists(rf): continue
        path = f'/tmp/own8_{key}.in'; mkinput.write(S['A'], S['C'], None, path)
        try: r = subprocess.run(['/home/claude/review/code/bnb', path], capture_output=True, text=True, timeout=int(sys.argv[4])).stdout
        except subprocess.TimeoutExpired: print(key, 'root search not finished within the time limit', flush=True); continue
        open(rf, 'w').write(r); lines = r.split('\n'); roots = [l for l in lines if l.startswith('ROOT')]; ssum = sum(int(l.split()[6]) for l in roots)
        unres = int([l for l in lines if l.startswith('SUMMARY')][0].split()[8])
        print(key, 'exact degree', S['degree'], '| positive roots', len(roots), 'sign sum', ssum, 'unresolved boxes', unres, '| match', ssum == S['degree'] and unres == 0, flush=True)
