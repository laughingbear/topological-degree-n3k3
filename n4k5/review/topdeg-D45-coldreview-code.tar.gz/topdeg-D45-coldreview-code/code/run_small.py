import sys, itertools
sys.path.insert(0, '/home/claude/review/code')
from sph import lutz, orient
from enc import Base, sphere_clauses
from pysat.solvers import Cadical153, Glucose4
E = '/home/claude/review/ext/'
byV = {}
for name, F in lutz(E + '3_manifolds_all.txt', E + '3_manifolds_all_type.txt'):
    V = 1 + max(max(f) for f in F); byV.setdefault(V, []).append((name, F))
print({V: len(L) for V, L in byV.items()})
for V, d in [(7, 3), (7, 4), (8, 4), (8, 5), (9, 5), (9, 6), (9, 7)]:
    base = Base(V); sat = []
    for name, F in byV[V]:
        eps = orient(F); nv = [base.nv]
        def new(): nv[0] += 1; return nv[0]
        cl = sphere_clauses(base, eps, d, new)
        if cl is None: continue
        res = []
        for S in (Cadical153, Glucose4):
            with S(bootstrap_with=base.clauses + cl) as s: res.append(s.solve())
        assert res[0] == res[1]
        if res[0]: sat.append(name)
    print(V, '>=', d, 'SAT:', len(sat), sat if len(sat) < 30 else '', flush=True)
