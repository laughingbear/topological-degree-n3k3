"""High-precision confirmation of the roots reported by bnb: Newton polish at 60 digits, relative residual, sign of det J."""
import sys, json, mpmath as mp
mp.mp.dps = 60
S = json.load(open(sys.argv[1])); A = S['A']; C = S['C'] if 'C' in S else S['C_by_degree'][sys.argv[3]]; N = len(A)
def FJ(y):
    L = [sum(mp.mpf(A[i][k]) * y[k] for k in range(4)) for i in range(N)]; M = max(L); w = [mp.e ** (l - M) for l in L]
    F = mp.matrix([sum(C[r][i] * w[i] for i in range(N)) for r in range(4)])
    J = mp.matrix(4, 4)
    for r in range(4):
        for k in range(4): J[r, k] = sum(C[r][i] * w[i] * A[i][k] for i in range(N))
    return F, J, w
tot = 0; rows = []
for l in open(sys.argv[2]):
    if not l.startswith('ROOT'): continue
    y = mp.matrix([mp.mpf(t) for t in l.split()[1:5]])
    for _ in range(8):
        F, J, w = FJ(y); y = y - mp.lu_solve(J, F)
    F, J, w = FJ(y); res = max(abs(f) for f in F); d = mp.det(J); scale = mp.mpf(1)
    for r in range(4): scale *= mp.norm(J[r, :])
    s = 1 if d > 0 else -1; tot += s
    rows.append((s, [mp.nstr(mp.e ** v, 8) for v in y], mp.nstr(res, 3), mp.nstr(d / scale, 3)))
for s, x, res, dn in rows: print('sign', '+' if s > 0 else '-', ' x =', ', '.join(x), ' residual', res, ' det J / row norms', dn)
print('roots', len(rows), 'sum of Jacobian signs', tot)
