import sys, pickle, gzip, json
O = '/home/claude/review/out/'; B = '/home/claude/bundle/topdeg4/v10/'
mine = {}
for p in (0, 1):
    for l in open(O + f'sweep8_inc_g4_part{p}.txt'):
        i, name, r = l.split(); mine[int(i)] = r
print('own sweep: spheres', len(mine), {k: sum(1 for r in mine.values() if r == k) for k in ('UNSAT', 'TRIV', 'SAT')})
auth = {int(l.split()[0]): l.split()[1] for l in gzip.open(B + 'sweep_ge8_results.txt.gz', 'rt') if l.strip()}
a2l = pickle.load(open(O + 'listmap.pkl', 'rb'))['a2l']
dis = [(ai, auth[ai], mine[a2l[ai]]) for ai in auth if (auth[ai] == 'SAT') != (mine[a2l[ai]] == 'SAT')]
triv = [(ai, auth[ai], mine[a2l[ai]]) for ai in auth if (auth[ai] == 'TRIV') != (mine[a2l[ai]] == 'TRIV')]
print('compared class by class with the author file:', len(auth), '| SAT/not-SAT disagreements:', len(dis), dis[:5], '| TRIV mismatches:', len(triv))
sat = sorted(i for i, r in mine.items() if r == 'SAT'); json.dump(sat, open(O + 'sat8_lutz_idx.json', 'w'))
L = pickle.load(open('/home/claude/review/ext/lutz10.pkl', 'rb')); pol = set(pickle.load(open(O + 'firsching_map.pkl', 'rb'))['polytopal_lutz_idx'])
print('own SAT set (Lutz names):', [L[i][0] for i in sat])
print('SAT and polytopal (Firsching):', sum(1 for i in sat if i in pol), '| SAT and non-polytopal:', sum(1 for i in sat if i not in pol))
# partial plain-mode run (first part of the list, fresh solver per sphere)
pl = {}
import glob
for f in glob.glob(O + 'partial/*.txt'):
    for l in open(f):
        i, name, r = l.split(); pl[int(i)] = r
print('plain-mode partial run:', len(pl), 'spheres, disagreements with incremental:', sum(1 for i in pl if pl[i] != mine[i]))
