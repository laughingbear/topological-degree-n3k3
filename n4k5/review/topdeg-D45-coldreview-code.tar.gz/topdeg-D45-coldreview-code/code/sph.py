"""Reviewer's sphere utilities: Lutz parser, orientation, checks. Own code."""
import re, gzip, itertools
def lutz(path, typepath, want='S^3'):
    """yield (name, facets 0-based sorted tuples) for complexes of the wanted type"""
    types = {}
    for l in open(typepath):
        if ':' in l: k, v = l.split(':', 1); types[k.strip()] = v.strip()
    op = gzip.open if path.endswith('.gz') else open
    txt = op(path, 'rt').read()
    for m in re.finditer(r'(manifold_\w+)\s*=\s*\[(.*?)\]\]', txt, re.S):
        name = m.group(1)
        if types.get(name) != want: continue
        F = [tuple(sorted(int(x) - 1 for x in g.split(','))) for g in re.findall(r'\[([\d,\s]+)', m.group(2) + ']')]
        yield name, sorted(F)
def orient(F):
    """coherent orientation: dict facet -> +-1.  A sorted facet f with sign e induces on the face omitting position i the
    orientation e*(-1)^i of the sorted triangle; two facets sharing a triangle must induce opposite orientations."""
    owner = {}
    for f in F:
        for i in range(4):
            owner.setdefault(f[:i] + f[i+1:], []).append((f, i))
    eps = {F[0]: 1}; todo = [F[0]]
    while todo:
        f = todo.pop()
        for i in range(4):
            pair = owner[f[:i] + f[i+1:]]
            if len(pair) != 2: raise ValueError('not a pseudomanifold')
            (g, j), = [p for p in pair if p[0] != f]
            want = -eps[f] * (-1) ** i * (-1) ** j      # eps_g*(-1)^j = -eps_f*(-1)^i
            if g in eps:
                if eps[g] != want: raise ValueError('not orientable')
            else: eps[g] = want; todo.append(g)
    if len(eps) != len(F): raise ValueError('not connected')
    return eps
