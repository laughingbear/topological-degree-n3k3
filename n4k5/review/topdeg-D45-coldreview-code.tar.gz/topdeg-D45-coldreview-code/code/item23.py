import sys, json, itertools, subprocess, random
sys.path.insert(0, '/home/claude/review/code')
from exact import det, colsub, sgn, UC, sphere_check, generic, in_cone
from sph import orient
B = '/home/claude/bundle/topdeg4/v10/'
S = json.load(open(B + 'sphere_deg9.json')); F = sorted(tuple(f) for f in S['facets'])
V = 10
print('facets', len(F), 'sphere_check (pseudomanifold, 2-sphere links, chi=0):', sphere_check(F))
E = {e for f in F for e in itertools.combinations(f, 2)}; T = {t for f in F for t in itertools.combinations(f, 3)}
print('f-vector', (V, len(E), len(T), len(F)), 'facets per vertex', sorted(sum(v in f for f in F) for v in range(V)))
non = [e for e in itertools.combinations(range(V), 2) if e not in E]; print('non-edges', non)
# automorphisms by brute force: extend a map facet->facet
def automorphisms(F):
    Fs = set(F); nbr = {}
    for f in F:
        for i in range(4): nbr.setdefault(f[:i] + f[i+1:], []).append(f)
    auts = []
    f0 = F[0]
    for g in F:
        for perm in itertools.permutations(g):
            m = dict(zip(f0, perm)); queue = [f0]; seen = {f0}; ok = True
            while queue and ok:
                f = queue.pop()
                for i in range(4):
                    t = f[:i] + f[i+1:]; h = [x for x in nbr[t] if x != f][0]
                    if h in seen: continue
                    w = [x for x in h if x not in t][0]
                    it = tuple(sorted(m[x] for x in t)); cand = [x for x in nbr.get(it, []) if x != tuple(sorted(m[x] for x in f))]
                    if len(cand) != 1: ok = False; break
                    iw = [x for x in cand[0] if x not in it][0]
                    if w in m and m[w] != iw: ok = False; break
                    m[w] = iw; seen.add(h); queue.append(h)
            if ok and len(m) == V and len(set(m.values())) == V and {tuple(sorted(m[x] for x in f)) for f in F} == Fs: auts.append(m)
    return auts
auts = automorphisms(F); print('|Aut| =', len(auts), 'vertex orbits:', len({frozenset(a[v] for a in auts) for v in range(V)}))
match = {a: b for a, b in non}; match.update({b: a for a, b in non})
print('matching involution is an automorphism:', {tuple(sorted(match[x] for x in f)) for f in F} == set(F))
# --- item 3: the degree-9 vertex map
M = json.load(open(B + 'vertexmap_deg9_nonpolytopal.json')); C = M['C']
eps_a = {tuple(G): e for G, e in M['oriented_facets']}
assert set(eps_a) == set(F)
eps = orient(F); rel = {eps[f] * eps_a[f] for f in F}; print('author orientation coherent (equals mine up to global sign):', len(rel) == 1)
print('max |C| entry', max(abs(x) for r in C for x in r), '(U_C):', UC(C))
def vdeg(eps, C, u):
    t = 0
    for G, e in eps.items():
        ic = in_cone(C, G, u)
        if ic is None: return None
        if ic: t += e * sgn(det(colsub(C, G)))
    return t
rnd = random.Random(5); us = [[-C[r][v] for r in range(4)] for v in range(V)] + [[rnd.randint(-999, 999) for _ in range(4)] for _ in range(200)]
degs = [vdeg(eps_a, C, u) for u in us if generic(C, u)]
print('degree over', len(degs), 'generic u (incl. u = -C_v for all v):', sorted(set(degs)))
print('facet signs eps*sign det:', sorted({eps_a[f] * sgn(det(colsub(C, f))) for f in F}))
cover = [sum(1 for G in F if in_cone(C, G, u)) for u in us if generic(C, u)]; print('number of facets covering u:', sorted(set(cover)))
