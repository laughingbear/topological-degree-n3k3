"""Reviewer's positive controls at V = 10: for real C, fix the chirotope to the true signs; the formula "degree >= d" must be
SAT at d = deg and UNSAT at d = deg + 1 (deg = exact degree for the orientation used, sign included)."""
import sys, json, pickle, random, subprocess, itertools
sys.path.insert(0, '/home/claude/review/code')
from exact import det, colsub, sgn, UC, in_cone, generic, facets
from sph import orient
from enc import Base, sphere_clauses, fix_chirotope
from pysat.solvers import Solver
base = Base(10)
def exact_degree(eps, C):
    """degree at u = -C_v for every v, and at some random u; all must agree"""
    vals = set(); rnd = random.Random(1)
    us = [[-C[r][v] for r in range(4)] for v in range(10)] + [[rnd.randint(-10**6, 10**6) for _ in range(4)] for _ in range(5)]
    for u in us:
        if not generic(C, u): continue
        vals.add(sum(e * sgn(det(colsub(C, G))) for G, e in eps.items() if in_cone(C, G, u)))
    assert len(vals) == 1, vals
    return vals.pop()
def control(eps, C, solver='g4'):
    D = exact_degree(eps, C); units = fix_chirotope(base, C); res = []
    for d in (D, D + 1):
        top = [base.nv]
        def new(): top[0] += 1; return top[0]
        cl = sphere_clauses(base, eps, d, new)
        if cl is None: res.append(False); continue
        with Solver(name=solver, bootstrap_with=base.clauses + units + cl) as s: res.append(s.solve())
    return D, res == [True, False]
def climb(F, eps, seed, steps, restart=3000, target=99):
    inp = f'10 {len(F)}\n' + '\n'.join(' '.join(map(str, G)) + f' {eps[G]}' for G in F) + '\n'
    out = subprocess.run(['/home/claude/review/code/climb', str(seed), str(steps), str(restart), str(target)], input=inp, capture_output=True, text=True).stdout.split('\n')
    Cf = [list(map(float, l.split())) for l in out[1:11]]
    for scale in (40, 100, 300, 1000, 10000):
        Ci = [[round(Cf[v][r] * scale) for v in range(10)] for r in range(4)]
        if UC(Ci): return Ci
    return None
if __name__ == '__main__':
    mode = sys.argv[1]; n = int(sys.argv[2]); L = pickle.load(open('/home/claude/review/ext/lutz10.pkl', 'rb')); rnd = random.Random(int(sys.argv[3]) if len(sys.argv) > 3 else 0)
    hist = {}; bad = 0
    if mode == 'random':
        for t in range(n):
            name, F = L[rnd.randrange(len(L))]; eps = orient(F)
            while True:
                C = [[rnd.randint(-99, 99) for _ in range(10)] for _ in range(4)]
                if UC(C): break
            D, ok = control(eps, C); hist[abs(D)] = hist.get(abs(D), 0) + 1; bad += not ok
    elif mode == 'climb':
        idx = json.load(open(sys.argv[4])) if len(sys.argv) > 4 else None
        for t in range(n):
            name, F = L[idx[t % len(idx)] if idx else rnd.randrange(len(L))]; eps = orient(F)
            C = climb(F, eps, rnd.randrange(10**9), int(sys.argv[5]) if len(sys.argv) > 5 else 150000)
            if C is None: continue
            D, ok = control(eps, C); hist[abs(D)] = hist.get(abs(D), 0) + 1; bad += not ok
            if not ok: print('MISMATCH', name, C)
    elif mode == 'exact':
        Bd = '/home/claude/bundle/topdeg4/v10/'
        S = json.load(open(Bd + 'D45_family.json')); fac = facets(S['A']); epsA = {G: e for G, e in fac}; F = sorted(epsA)
        eps = orient(F); assert len({eps[G] * epsA[G] for G in F}) == 1
        for k, C in S['C_by_degree'].items():
            for e2 in (eps, {G: -e for G, e in eps.items()}):
                D, ok = control(e2, C); hist[D] = hist.get(D, 0) + 1; bad += not ok; print('family', k, 'degree', D, 'control ok', ok)
        M = json.load(open(Bd + 'vertexmap_deg9_nonpolytopal.json')); eps9 = {tuple(G): e for G, e in M['oriented_facets']}
        for e2 in (eps9, {G: -e for G, e in eps9.items()}):
            D, ok = control(e2, M['C']); hist[D] = hist.get(D, 0) + 1; bad += not ok; print('degree-9 map on sphere 101272: degree', D, 'control ok', ok)
    print(mode, 'controls', sum(hist.values()), 'mismatches', bad, 'degree histogram', sorted(hist.items()))
