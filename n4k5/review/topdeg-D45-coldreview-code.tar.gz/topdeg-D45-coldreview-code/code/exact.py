"""Reviewer's exact verifier (Python integers only). Written from Bihan arXiv:2611.34336 Thm 1.3, not from the author's code.
deg F = (-1)^n * sum over facets G of conv(A) with u in cone(C_G) of sign det(C_G) * eps_G,
eps_G = sign det of the (n+1)x(n+1) matrix with columns (1,a_s), s in G increasing, then (1,a_i) for any i off G."""
import itertools, json, sys, random
def det(M):
    n = len(M)
    if n == 1: return M[0][0]
    if n == 2: return M[0][0]*M[1][1] - M[0][1]*M[1][0]
    M = [list(r) for r in M]; sign = 1; prev = 1          # Bareiss, exact on integers
    for k in range(n - 1):
        if M[k][k] == 0:
            p = next((r for r in range(k + 1, n) if M[r][k] != 0), None)
            if p is None: return 0
            M[k], M[p] = M[p], M[k]; sign = -sign
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                M[i][j] = (M[i][j]*M[k][k] - M[i][k]*M[k][j]) // prev
        prev = M[k][k]
    return sign * M[n-1][n-1]
sgn = lambda x: (x > 0) - (x < 0)
def colsub(M, idx): return [[row[j] for j in idx] for row in M]
def hom(A): return [[1]*len(A)] + [[a[r] for a in A] for r in range(len(A[0]))]
def UA(A):
    Ah = hom(A); n = len(A[0])
    return all(det(colsub(Ah, s)) != 0 for s in itertools.combinations(range(len(A)), n + 1))
def UC(C):
    n = len(C); return all(det(colsub(C, s)) != 0 for s in itertools.combinations(range(len(C[0])), n))
def facets(A):
    """facets of conv(A) as (sorted n-tuple, eps); requires each facet to have exactly n points (true under U_A)"""
    Ah = hom(A); N = len(A); n = len(A[0]); out = []
    for G in itertools.combinations(range(N), n):
        s = [sgn(det(colsub(Ah, G + (i,)))) for i in range(N) if i not in G]
        if all(x == 1 for x in s): out.append((G, 1))
        elif all(x == -1 for x in s): out.append((G, -1))
    return out
def in_cone(C, G, u):
    """u in open cone of columns G of C, by Cramer; None if u on the boundary"""
    n = len(C); CG = colsub(C, G); d = det(CG); res = True
    for c in range(n):
        M = [[CG[r][j] if j != c else u[r] for j in range(n)] for r in range(n)]
        l = det(M) * sgn(d)
        if l == 0: return None
        if l < 0: res = False
    return res
def degree(fac, C, u):
    n = len(C); tot = 0
    for G, eps in fac:
        ic = in_cone(C, G, u)
        if ic is None: return None
        if ic: tot += sgn(det(colsub(C, G))) * eps
    return (-1)**n * tot
def generic(C, u):
    n = len(C)
    return all(det([[C[r][j] for j in s] + [u[r]] for r in range(n)]) != 0 for s in itertools.combinations(range(len(C[0])), n - 1))
def sphere_check(F):
    """F list of sorted 4-tuples: closed pseudomanifold, vertex links are 2-spheres, Euler char"""
    from collections import Counter
    tri = Counter(t for f in F for t in itertools.combinations(f, 3))
    if set(tri.values()) != {2}: return False
    V = sorted({v for f in F for v in f}); E = {e for f in F for e in itertools.combinations(f, 2)}
    if len(V) - len(E) + len(tri) - len(F) != 0: return False
    for v in V:
        L = [tuple(x for x in f if x != v) for f in F if v in f]
        lv = {x for t in L for x in t}; le = Counter(e for t in L for e in itertools.combinations(t, 2))
        if set(le.values()) != {2} or len(lv) - len(le) + len(L) != 2: return False
        # connected
        adj = {x: set() for x in lv}
        for a, b in le: adj[a].add(b); adj[b].add(a)
        seen = {next(iter(lv))}; st = list(seen)
        while st:
            for y in adj[st.pop()]:
                if y not in seen: seen.add(y); st.append(y)
        if seen != lv: return False
    return True
def report(A, C, nu=60, seed=7):
    fac = facets(A); F = [G for G, _ in fac]; N = len(A)
    verts = sorted({v for G in F for v in G})
    rnd = random.Random(seed); degs = []
    us = [[-C[r][v] for r in range(len(C))] for v in range(N)]
    while len(us) < nu + N: us.append([rnd.randint(-99, 99) for _ in C])
    for u in us:
        if not generic(C, u): continue
        degs.append(degree(fac, C, u))
    signs = [sgn(det(colsub(C, G))) * e for G, e in fac]
    return dict(UA=UA(A), UC=UC(C), nvert=len(verts), nfac=len(F), sphere=sphere_check(F), degs=sorted(set(degs)), nu=len(degs), pos=signs.count(1), neg=signs.count(-1))
if __name__ == '__main__':
    S = json.load(open(sys.argv[1]))
    if 'C_by_degree' in S:
        for k, C in S['C_by_degree'].items(): print(k, report(S['A'], C))
    else: print(report(S['A'], S['C']))
