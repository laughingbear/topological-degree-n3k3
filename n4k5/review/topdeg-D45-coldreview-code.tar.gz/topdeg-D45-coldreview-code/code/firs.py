"""Firsching's realizations of polytopal 10-vertex simplicial 3-spheres (Lutz numbering): index convention and hulls"""
import sys, re, pickle, random
sys.path.insert(0, '/home/claude/review/code')
from fractions import Fraction as Fr
import numpy as np
from scipy.spatial import ConvexHull
E = '/home/claude/review/ext/'
def load():
    out = {}
    for l in open(E + 'poly10.txt'):
        k, rest = l.split(':', 1); out[int(k[1:])] = rest.strip()
    return out
def coords(s): return [[Fr(x) for x in row.split(',')] for row in re.findall(r'\[([^\[\]]+)\]', s)]
if __name__ == '__main__':
    P = load(); L = pickle.load(open(E + 'lutz10.pkl', 'rb')); byname = {n: F for n, F in L}
    print('entries', len(P), 'min/max index', min(P), max(P))
    random.seed(3); ks = random.sample(sorted(P), 3000); agree = 0; miss = 0
    for k in ks:
        A = np.array([[float(x) for x in r] for r in coords(P[k])]); h = ConvexHull(A)
        Fh = sorted(tuple(sorted(int(v) for v in s)) for s in h.simplices)
        F = byname.get(f'manifold_3_10_{k}')
        if F is None: miss += 1
        elif F == Fh: agree += 1
    print('sample of', len(ks), ': float hull facets identical to Lutz manifold_3_10_k (same labels):', agree, '| index not an S^3 in Lutz:', miss)
    names = {n for n, _ in L}; print('all Firsching indices are S^3 entries of Lutz:', all(f'manifold_3_10_{k}' in names for k in P))
