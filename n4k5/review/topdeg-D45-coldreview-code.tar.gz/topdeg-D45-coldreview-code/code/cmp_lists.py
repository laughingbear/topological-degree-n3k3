"""compare the author's regenerated spheres10.json with Lutz's S^3 list, class by class, via canon.cpp"""
import sys, json, pickle, subprocess
L = pickle.load(open('/home/claude/review/ext/lutz10.pkl', 'rb'))
Au = json.load(open('/home/claude/review/authorrun/spheres10.json'))
def canon(lists):
    inp = '\n'.join(str(len(F)) + ' ' + ' '.join(str(v) for f in F for v in f) for F in lists) + '\n'
    out = subprocess.run(['/home/claude/review/code/canon'], input=inp, capture_output=True, text=True).stdout.split('\n')
    return [tuple(l.split()) for l in out if l]
cl = canon([F for _, F in L]); ca = canon(Au)
kl = {c[1:]: i for i, c in enumerate(cl)}; ka = {c[1:]: i for i, c in enumerate(ca)}
print('Lutz S^3:', len(cl), 'distinct classes', len(kl), '| author:', len(ca), 'distinct classes', len(ka))
print('only Lutz:', len(set(kl) - set(ka)), 'only author:', len(set(ka) - set(kl)))
a2l = {ka[k]: kl[k] for k in ka if k in kl}
pickle.dump({'a2l': a2l, 'aut_lutz': [int(c[0]) for c in cl], 'canon_lutz': [c[1:] for c in cl]}, open('/home/claude/review/out/listmap.pkl', 'wb'))
