"""Identify Firsching's 162,004 polytopal 10-vertex spheres in Lutz's S^3 list by (float) convex hull + canonical form;
exact rational hull for the ones that matter."""
import sys, re, pickle, subprocess
sys.path.insert(0, '/home/claude/review/code')
import numpy as np
from scipy.spatial import ConvexHull
from fractions import Fraction as Fr
E = '/home/claude/review/ext/'; O = '/home/claude/review/out/'
M = pickle.load(open(O + 'listmap.pkl', 'rb')); canon2l = {c: i for i, c in enumerate(M['canon_lutz'])}
num = re.compile(r'(-?\d+)(?:/(\d+))?')
keys = []; hulls = []; bad = 0; raw = {}
for l in open(E + 'poly10.txt'):
    k, rest = l.split(':', 1); k = int(k[1:]); raw[k] = rest
    v = [int(a) / int(b) if b else float(a) for a, b in num.findall(rest)]
    A = np.array(v).reshape(10, 4); h = ConvexHull(A)
    if len(h.vertices) != 10 or h.simplices.shape[1] != 4: bad += 1
    keys.append(k); hulls.append(sorted(tuple(sorted(int(x) for x in s)) for s in h.simplices))
inp = '\n'.join(str(len(F)) + ' ' + ' '.join(str(v) for f in F for v in f) for F in hulls) + '\n'
out = [tuple(l.split()) for l in subprocess.run(['/home/claude/review/code/canon'], input=inp, capture_output=True, text=True).stdout.split('\n') if l]
f2l = {}; unmatched = 0
for k, c in zip(keys, out):
    if c[1:] in canon2l: f2l[k] = canon2l[c[1:]]
    else: unmatched += 1
print('Firsching entries', len(keys), 'hulls not 10-vertex simplicial (float):', bad, 'unmatched to a Lutz S^3 class:', unmatched, 'distinct Lutz classes hit:', len(set(f2l.values())))
pickle.dump({'f2l': f2l, 'polytopal_lutz_idx': sorted(set(f2l.values()))}, open(O + 'firsching_map.pkl', 'wb'))
D = pickle.load(open(O + 'item4d.pkl', 'rb')); l2f = {v: k for k, v in f2l.items()}
from exact import facets, UA
for ai in D['sat_author']:
    li = D['a2l39'][ai]; fk = l2f.get(li); tag = 'realization supplied by author' if ai in D['real'] else ('sphere 101272' if ai == 101272 else 'rank-5 UNSAT')
    ex = ''
    if fk is not None:
        A = [[Fr(a, int(b) if b else 1) for a, b in [(int(a), b) for a, b in num.findall(raw[fk])][4*i:4*i+4]] for i in range(10)]
        den = 1
        for r in A:
            for x in r: den = den * x.denominator // __import__('math').gcd(den, x.denominator)
        Ai = [[int(x * den) for x in r] for r in A]; fac = facets(Ai); F = sorted(G for G, _ in fac)
        inp1 = str(len(F)) + ' ' + ' '.join(str(v) for f in F for v in f) + '\n'
        c = tuple(subprocess.run(['/home/claude/review/code/canon'], input=inp1, capture_output=True, text=True).stdout.split())
        ex = 'exact hull of Firsching coordinates is this type: %s' % (c[1:] == M['canon_lutz'][li])
    print(ai, tag, '| in Firsching polytopal list:', 'yes (i%d)' % fk if fk is not None else 'NO', ex)
