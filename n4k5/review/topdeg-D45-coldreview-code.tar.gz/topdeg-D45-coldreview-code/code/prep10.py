"""parse Lutz's 10-vertex list once -> pickle of (name, facets) for the S^3 entries"""
import sys, pickle
sys.path.insert(0, '/home/claude/review/code')
from sph import lutz
E = '/home/claude/review/ext/'
L = list(lutz(E + '3_manifolds_10_all.txt.gz', E + '3_manifolds_10_all_type.txt'))
print(len(L), min(len(F) for _, F in L), max(len(F) for _, F in L), {1 + max(max(f) for f in F) for _, F in L})
pickle.dump(L, open(E + 'lutz10.pkl', 'wb'))
