import sys, pickle, json, re
sys.path.insert(0, '/home/claude/review/code')
from sph import lutz
from poly5 import polytopal_possible, enumerate_chi
E = '/home/claude/review/ext/'
byV = {}
for name, F in lutz(E + '3_manifolds_all.txt', E + '3_manifolds_all_type.txt'):
    byV.setdefault(1 + max(max(f) for f in F), []).append((name, F))
for V in (5, 6, 7, 8, 9):
    uns = []
    for name, F in byV[V]:
        r = [polytopal_possible(V, F, s) for s in ('g4', 'cd15')]; assert r[0] == r[1]
        if not r[0]: uns.append(name)
    print('V =', V, 'spheres', len(byV[V]), 'rank-5 test SAT', len(byV[V]) - len(uns), 'UNSAT', len(uns), uns if len(uns) < 5 else '', flush=True)
    if V == 9:
        # Firsching's list of polytopal 9-vertex spheres (Lutz numbering, 1142 entries): compare
        pol = {int(l.split(':')[0][1:]) for l in open(E + 'poly9.txt') if ':' in l}
        nonpol = [n for n, F in byV[9] if int(n.split('_')[-1]) not in pol]
        print('   Firsching: polytopal', len(pol), 'non-polytopal', len(nonpol), '| UNSAT subset of non-polytopal:', set(uns) <= set(nonpol), '| non-polytopal but SAT:', sorted(set(nonpol) - set(uns)))
    if V == 8:
        pol = {int(l.split(':')[0][1:]) for l in open(E + 'poly8.txt') if ':' in l}
        print('   Firsching: polytopal', len(pol), '| UNSAT = complement:', {int(n.split('_')[-1]) for n in uns} == {int(n.split('_')[-1]) for n, F in byV[8]} - pol)
D = pickle.load(open('/home/claude/review/out/item4d.pkl', 'rb')); L = pickle.load(open(E + 'lutz10.pkl', 'rb'))
out = {}
for ai in D['sat_author']:
    name, F = L[D['a2l39'][ai]]; r = [polytopal_possible(10, F, s) for s in ('g4', 'cd15', 'mc')]; assert len(set(r)) == 1
    out[ai] = r[0]
    print(ai, name, 'facets', len(F), 'realization supplied' if ai in D['real'] else 'no realization', '| rank-5 test:', 'SAT' if r[0] else 'UNSAT', flush=True)
print('no realization & UNSAT:', sum(1 for ai in out if ai not in D['real'] and not out[ai]), '| no realization & SAT:', [ai for ai in out if ai not in D['real'] and out[ai]], '| realization & UNSAT (would be an error):', [ai for ai in out if ai in D['real'] and not out[ai]])
