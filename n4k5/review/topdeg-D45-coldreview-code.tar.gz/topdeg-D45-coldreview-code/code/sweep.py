"""Reviewer's V = 10 sweep on Lutz's list.  usage: sweep.py d out part nparts mode solver [indexfile]
mode 'inc': one solver holds the base clauses; each sphere's counter clauses carry an activation literal (fresh auxiliaries),
            solved under that assumption, then disabled by a unit clause; solver rebuilt every BATCH spheres.
mode 'plain': a fresh solver per sphere."""
import sys, pickle, time, json
sys.path.insert(0, '/home/claude/review/code')
from sph import orient
from enc import Base, sphere_clauses
from pysat.solvers import Solver
d = int(sys.argv[1]); outp = sys.argv[2]; part = int(sys.argv[3]); nparts = int(sys.argv[4]); mode = sys.argv[5]; sname = sys.argv[6]
L = pickle.load(open('/home/claude/review/ext/lutz10.pkl', 'rb'))
idx = json.load(open(sys.argv[7])) if len(sys.argv) > 7 else range(len(L))
idx = [i for k, i in enumerate(idx) if k % nparts == part]
done = set()
try: done = {int(l.split()[0]) for l in open(outp) if l.strip()}
except FileNotFoundError: pass
base = Base(10); BATCH = 300; out = open(outp, 'a'); t0 = time.time(); solver = None; nin = 0; cnt = {}
for i in idx:
    if i in done: continue
    name, F = L[i]; eps = orient(F)
    if mode == 'inc':
        if solver is None or nin >= BATCH:
            if solver is not None: solver.delete()
            solver = Solver(name=sname, bootstrap_with=base.clauses); nin = 0; top = [base.nv]
        def new(): top[0] += 1; return top[0]
        act = new(); cl = sphere_clauses(base, eps, d, new)
        if cl is None: res = 'TRIV'
        else:
            for c in cl: solver.add_clause(c + [-act])
            res = 'SAT' if solver.solve(assumptions=[act]) else 'UNSAT'
        solver.add_clause([-act]); nin += 1
    else:
        top = [base.nv]
        def new(): top[0] += 1; return top[0]
        cl = sphere_clauses(base, eps, d, new)
        if cl is None: res = 'TRIV'
        else:
            with Solver(name=sname, bootstrap_with=base.clauses + cl) as s: res = 'SAT' if s.solve() else 'UNSAT'
    cnt[res] = cnt.get(res, 0) + 1; out.write(f'{i} {name} {res}\n'); out.flush()
out.close(); print('d', d, 'part', part, mode, sname, cnt, round(time.time() - t0), 's', flush=True)
