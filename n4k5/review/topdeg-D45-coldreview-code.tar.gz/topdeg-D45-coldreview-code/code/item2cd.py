import sys, json, itertools
sys.path.insert(0, '/home/claude/review/code')
from poly5 import base5, units, enumerate_chi
B = '/home/claude/bundle/topdeg4/v10/'
F = sorted(tuple(f) for f in json.load(open(B + 'sphere_deg9.json'))['facets']); V = 10
b = base5(V); u = units(V, F); print('GP clauses', len(b.clauses), 'variables', b.nv, 'fixed by the facets', len(u), 'free', b.nv - len(u))
sets = {}
for sv in ('cd15', 'g4', 'mc', 'lgl', 'cd19'):
    try: ms = enumerate_chi(V, F, sv)
    except Exception as e: print(sv, 'unavailable', e); continue
    sets[sv] = {tuple(m) for m in ms}; print(sv, 'compatible chirotopes:', len(ms))
assert len({frozenset(s) for s in sets.values()}) == 1
mine = sorted(next(iter(sets.values())))
# author's four
D = json.load(open(B + 'chi27.json')); subs = list(itertools.combinations(range(V), 5))
auth = []
for model in D['models']:
    sign = {}
    for l in D['units'] + model: sign[abs(l)] = 1 if l > 0 else -1
    assert len(sign) == 252; auth.append(tuple(v * sign[v] for v in range(1, 253)))
# global sign: my orientation may be the negative of the author's
neg = lambda m: tuple(-l for l in m)
same = set(auth) == set(mine); opp = {neg(m) for m in auth} == set(mine)
print('author chirotopes equal mine:', same, '| equal after global sign change:', opp)
if opp and not same: auth = [neg(m) for m in auth]          # certificates do not depend on the global sign
json.dump([list(m) for m in mine], open('/home/claude/review/out/chi_101272_reviewer.json', 'w'))
# --- certificates: recompute the valid inequalities from the chirotope, then check the author's rows and weights exactly
def lit_sign(m, t):
    l = b.lit(t); return m[abs(l) - 1] // abs(m[abs(l) - 1]) * (1 if l > 0 else -1)
def inequalities(m):
    out = set(); n = 0
    for sig in itertools.combinations(range(V), 3):
        rest = [z for z in range(V) if z not in sig]
        for a, bb, c, d in itertools.combinations(rest, 4):
            pairs = [((sig + (a, bb)), (sig + (c, d)), 1), ((sig + (a, c)), (sig + (bb, d)), -1), ((sig + (a, d)), (sig + (bb, c)), 1)]
            s = [lit_sign(m, p) * lit_sign(m, q) * k for p, q, k in pairs]
            assert sorted(s) in ([-1, 1, 1], [-1, -1, 1])
            mi = s.index(-1) if sum(s) == 1 else s.index(1); n += 1
            for j in range(3):
                if j == mi: continue
                row = {}
                for S_, co in ((pairs[mi][0], 1), (pairs[mi][1], 1), (pairs[j][0], -1), (pairs[j][1], -1)):
                    k = subs.index(tuple(sorted(S_))); row[k] = row.get(k, 0) + co
                out.add(tuple(sorted((k, v) for k, v in row.items() if v)))
    return out, n
certs = json.load(open(B + 'bfp27.json'))
for r in certs:
    m = auth[r['model']]; ineq, n = inequalities(m); c = r['certificate']
    rows = [tuple(sorted((int(k), v) for k, v in row.items())) for row in c['rows']]; w = c['weights']
    valid = all(row in ineq for row in rows); tot = [0] * 252
    for row, wi in zip(rows, w):
        for k, v in row: tot[k] += wi * v
    print('chirotope', r['model'], 'GP relations', n, 'inequalities', 2 * n, '(distinct', len(ineq), ') certificate rows', len(rows),
          '| every row is a valid inequality of this chirotope:', valid, '| weights integers >= 0, not all 0:', all(isinstance(x, int) and x >= 0 for x in w) and sum(w) > 0,
          '| weighted sum is the zero vector:', all(t == 0 for t in tot), '| weight range', min(w), max(w))
