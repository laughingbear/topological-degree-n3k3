// Reviewer's hill-climber: maximise |degree| of the vertex map (K, C) for one oriented simplicial 3-sphere K on V vertices.
// degree at a fixed generic u: sum over facets G with u in cone(C_G) of eps_G * sign det C_G  (Cramer's rule).
// input (stdin): V nf, then nf lines "a b c d eps".  args: seed steps restart.  output: best degree and C (V rows).
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <random>
#include <cstring>
int V, nf, F[64][4], E[64]; double C[16][4], u[4];
static double det4(const double *a, const double *b, const double *c, const double *d) {
  double m[4][4]; for (int i = 0; i < 4; i++) { m[i][0] = a[i]; m[i][1] = b[i]; m[i][2] = c[i]; m[i][3] = d[i]; }
  double r = 0; int p[4] = {0, 1, 2, 3};
  // Laplace along the first row
  for (int j = 0; j < 4; j++) { int c0[3], k = 0; for (int q = 0; q < 4; q++) if (q != j) c0[k++] = q;
    double mn = m[1][c0[0]] * (m[2][c0[1]] * m[3][c0[2]] - m[2][c0[2]] * m[3][c0[1]]) - m[1][c0[1]] * (m[2][c0[0]] * m[3][c0[2]] - m[2][c0[2]] * m[3][c0[0]]) + m[1][c0[2]] * (m[2][c0[0]] * m[3][c0[1]] - m[2][c0[1]] * m[3][c0[0]]);
    r += ((j & 1) ? -1 : 1) * m[0][j] * mn; } (void)p;
  return r; }
int degree() { int t = 0;
  for (int f = 0; f < nf; f++) { const double *a = C[F[f][0]], *b = C[F[f][1]], *c = C[F[f][2]], *d = C[F[f][3]];
    double D = det4(a, b, c, d); int s = D > 0 ? 1 : -1;
    if (det4(u, b, c, d) * s > 0 && det4(a, u, c, d) * s > 0 && det4(a, b, u, d) * s > 0 && det4(a, b, c, u) * s > 0) t += E[f] * s; }
  return t; }
int main(int argc, char **argv) {
  if (scanf("%d %d", &V, &nf) != 2) return 1;
  for (int f = 0; f < nf; f++) if (scanf("%d %d %d %d %d", &F[f][0], &F[f][1], &F[f][2], &F[f][3], &E[f]) != 5) return 1;
  std::mt19937_64 rng(atol(argv[1])); long steps = atol(argv[2]); int restart = atoi(argv[3]); int target = argc > 4 ? atoi(argv[4]) : 99;
  std::normal_distribution<double> g(0, 1); std::uniform_real_distribution<double> U(0, 1);
  int cur = -1, stale = 0, best = -1; double Cb[16][4], ub[4];
  for (long it = 0; it < steps && best < target; it++) {
    if (cur < 0 || stale > restart) { for (int i = 0; i < V; i++) for (int j = 0; j < 4; j++) C[i][j] = g(rng); for (int j = 0; j < 4; j++) u[j] = g(rng); cur = abs(degree()); stale = 0; }
    int v = rng() % V; double save[4]; memcpy(save, C[v], sizeof save); double r = U(rng), sc = r < 0.25 ? 1.0 : (r < 0.6 ? 0.4 : (r < 0.85 ? 0.12 : 0.03));
    if (r < 0.1) for (int j = 0; j < 4; j++) C[v][j] = g(rng); else for (int j = 0; j < 4; j++) C[v][j] += sc * g(rng);
    int e = abs(degree());
    if (e >= cur) { if (e > cur) stale = 0; else stale++; cur = e; } else { memcpy(C[v], save, sizeof save); stale++; }
    if (cur > best) { best = cur; memcpy(Cb, C, sizeof C); memcpy(ub, u, sizeof u); }
  }
  printf("%d\n", best); for (int i = 0; i < V; i++) printf("%.17g %.17g %.17g %.17g\n", Cb[i][0], Cb[i][1], Cb[i][2], Cb[i][3]);
}
