Reviewer's code and results for the cold review of topdeg-D45-2026-11-26.md.  See topdeg-D45-coldreview.md.
Paths inside the scripts are absolute (/home/claude/review/code, /home/claude/review/ext for downloaded data,
/home/claude/bundle/topdeg4 for the bundle under review); adjust before re-running.
Build: g++ -O2 -o bnb bnb.cpp ; g++ -O2 -o canon canon.cpp ; g++ -O2 -o climb climb.cpp.   Python: pysat, numpy, scipy, mpmath.
Order: prep10.py -> cmp_lists.py -> sweep.py 8 out part nparts inc g4 -> cmp_sweep.py ; item*.py ; firs2.py ; v9check.py ; controls.py.
Roots: mkinput.py system.json auto in.txt [label] ; ./bnb in.txt ; rootcheck.py system.json roots.txt [label].
out/own8/first_run_logs.txt: log of an interrupted first run; the systems of types 48162 and 48831 in that log were not saved.
